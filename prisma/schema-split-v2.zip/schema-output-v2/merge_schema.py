#!/usr/bin/env python3
"""
Merge schema fragments back into one schema.prisma.
Usage: python3 merge_schema.py ecommerce seo forms
       (core is always included automatically)

Handles injections for ANY model, not just tenant/user: each fragment
may carry "// INJECT_INTO:<model>" blocks that only get spliced back
in if that fragment's module is one of the ones you selected. If the
owner model itself isn't present (its module wasn't selected), the
injection is safely skipped.
"""
import sys, os, re

FRAGMENTS_DIR = "prisma/schema-output/fragments"
OUTPUT_PATH = "prisma/schema.prisma"

def main():
    selected = sys.argv[1:]
    core_path = os.path.join(FRAGMENTS_DIR, "schema.core.prisma")
    core = open(core_path, encoding="utf-8").read()

    module_bodies = []
    all_injections = []  # (owner_model, line_text)

    for mod in selected:
        path = os.path.join(FRAGMENTS_DIR, f"schema.{mod}.prisma")
        if not os.path.exists(path):
            print(f"WARNING: no fragment for module '{mod}', skipping")
            continue
        text = open(path, encoding="utf-8").read()

        # Pull out every INJECT_INTO block, regardless of target model name
        pat = re.compile(r"// INJECT_INTO:(\w+)\n(.*?)\n// END_INJECT:\1\n?", re.S)
        for m in pat.finditer(text):
            all_injections.append((m.group(1), m.group(2)))
        text = pat.sub("", text)
        text = text.replace(
            "// ---- Fields requiring this module, to be spliced back into their owner model at merge time ----\n", "")
        module_bodies.append(text.strip() + "\n")

    merged = core + "\n\n" + "\n".join(module_bodies)

    # Now splice injections into their owner model, wherever that model
    # currently lives (core or one of the selected module bodies). If the
    # owner model isn't present in the merged text, skip silently.
    for owner_model, line in all_injections:
        pattern = re.compile(
            rf"(model {re.escape(owner_model)} \{{.*?)(\n\}})", re.S)
        if pattern.search(merged):
            merged = pattern.sub(lambda m: m.group(1) + "\n" + line + m.group(2), merged, count=1)
        # else: owner model's module wasn't selected -> nothing to splice into, skip

    os.makedirs(os.path.dirname(OUTPUT_PATH) or ".", exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(merged)
    print(f"Wrote {OUTPUT_PATH} with modules: core + {', '.join(selected) if selected else '(none)'}")
    print("Now run: npx prisma validate")

if __name__ == "__main__":
    main()
